<meta charset='utf-8'>
<title>Charla de DrFrankNorton.</title>
<h1>Charla de DrFrankNorton.</h1>
<form method="POST"action="./register.php">
    <input name="username"placeholder="Introduce tu apodo."style="width:100%">
    <input name="password"type="password"placeholder="Introduce tu contraseña."style="width:100%">
    <input name="register"type="submit"style="width:100%">
</form>
<a href="./index.php">Return to login.</a>
<?php
if(
    isset($_POST['register'])
){
    $users1 = file_get_contents("datos/users.txt");

    $user1 = $_POST["username"].";".$_POST["password"].";";
        
    file_put_contents("datos/users.txt", $users1."".$user1);
}
?>
<style>
        body{
        	font-family:consolas;
        }
        #fecha{
                overflow: hidden;
                width: 100%;
                box-shadow:8px 8px 8px #000;
                text-shadow:8px 8px 8px #000;
                background-color:#048;
                border:8px solid #000;
				transition:1s;
        }
        #fecha:hover{
                overflow: hidden;
                box-shadow:8px 8px 8px #000;
                text-shadow:8px 8px 8px #000;
                background-color:#08f;
                width:100%;
                border:8px solid #000;
                transition:1s;
        }
        #demo{
                overflow: hidden;
                box-shadow:8px 8px 8px #000;
                text-shadow:8px 8px 8px #000;
                background-color:#048;
                width:100%;
                height:25%;
                border:8px solid #000;
                transition:1s;
        }
        #demo:hover{
                overflow: hidden;
                box-shadow:8px 8px 8px #000;
                text-shadow:8px 8px 8px #000;
                background-color:#08f;
                width:100%;
                height:25%;
                border:8px solid #000;
                transition:1s;
        }
        ::placeholder{
                color:#fff;
        }
        ::placeholder:hover{
                color:#fff;
        }

        input[type=range] {
                size: 100px;
                height: 38px;
                width: 400px;
                -webkit-appearance: none;
                margin: 10px 0;
                box-shadow:8px 8px 8px #000;
                text-shadow:8px 8px 8px #000;
        }
        input[type="range"]::-webkit-slider-thumb {
                -webkit-appearance: none; /* Override default look */
                appearance: none;
                background-color: #5cd5eb;
                height: 4rem;
                width: 2rem;
                border:8px solid #000000;
                box-shadow:8px 8px 4px #000;
                text-shadow:8px 8px 4px #000;
        }

        a:focus{
                outline: none;
        }
        a{
                text-decoration: none;
                display:inline-block;
        }
        a:hover{
                text-decoration: none;
                display:inline-block;
        }
        form{
                margin:0;
        }
        input:focus{
                outline: none;
        }
        .enviarmensaje{
                background-color:#004488;
                border:8px solid #000000;
                color:#000000;
                font-weight:bold;
                text-decoration: none;
                font-size:25px;
                word-wrap: nowrap;
                white-space: nowrap;
                display:inline-block;
                box-shadow:8px 8px 4px #000;
                text-shadow:4px 4px 4px #000;
                transition:1s;
        }
        .enviarmensaje:hover{
                background-color:#0066bb;
                border:8px solid #000000;
                color:#000000;
                font-weight:bold;
                text-decoration: none;
                font-size:25px;
                word-wrap: nowrap;
                white-space: nowrap;
                display:inline-block;
                box-shadow:8px 8px 4px #000;
                text-shadow:4px 4px 4px #000;
                transition:1s;
        }
        input{
                background-color:#004488;
                border:8px solid #000000;
                color:#000000;
                font-weight:bold;
                text-decoration: none;
                font-size:25px;
                word-wrap: nowrap;
                white-space: nowrap;
                display:inline-block;
                box-shadow:8px 8px 4px #000;
                text-shadow:8px 8px 4px #000;
        }
        input:hover{
                background-color:#0066bb;
                border:8px solid #000000;
                color:#000000;
                font-weight:bold;
                text-decoration: none;
                font-size:25px;
                word-wrap: nowrap;
                white-space: nowrap;
                display:inline-block;
                box-shadow:8px 8px 4px #000;
                text-shadow:8px 8px 4px #000;
        }
        a{
                background-color:#004488;
                border:8px solid #000000;
                color:#000000;
                font-weight:bold;
                text-decoration: none;
                font-size:25px;
                word-wrap: nowrap;
                white-space: nowrap;
                display:inline-block;
                box-shadow:8px 8px 4px #000;
                text-shadow:8px 8px 4px #000;
                width:100%;
                color:#fff;
        }
        a:hover{
                background-color:#0066bb;
                border:8px solid #000000;
                color:#000000;
                font-weight:bold;
                text-decoration: none;
                font-size:25px;
                word-wrap: nowrap;
                white-space: nowrap;
                display:inline-block;
                box-shadow:8px 8px 4px #000;
                text-shadow:8px 8px 4px #000;
                width:100%;
                color:#fff;
        }
        body{
                background-color:#0088ff;
                color:#fff;
                font-weight:bold;
                text-decoration:none;
                font-size:25px;
                overflow-y:scroll;
        }

        h1{
                background-color:#0088ff;
                color:#fff;
                font-weight:bold;
                text-decoration:none;
                font-size:15px;
                overflow:hidden;
                text-shadow:8px 8px 8px #000;
        }

        #tablero{
                border-collapse:collapse;
                float: left;
                width: 60%;
                box-shadow:8px 8px 8px #000;
                text-shadow:8px 8px 8px #000;
        }

        #log{
                border-collapse:collapse;
                float: left;
                width: 20%;
                height: 400px;
                margin-left: 5%;
                border: 4px solid #000;
                overflow:scroll;
        }

        #tablero td, #tablero th{
                border: 16px solid #000;			
                width:100px;
                height:100px;
                text-align: center;
                margin: 0;
                background: #048;
                font-size: 2em;
        }

        .clear{
                clear: both;
        }

        #log{
                padding: 1em;
        }

        #log p:nth-child(1){
                font-weight: bold;
        }

        button {
                margin-top: 1em;
        }

        .j1{
                color: red;
        }

        .j2{
                color: blue;
        }

        h1{
                font-size:50px;
                text-align:center;
        }
</style>