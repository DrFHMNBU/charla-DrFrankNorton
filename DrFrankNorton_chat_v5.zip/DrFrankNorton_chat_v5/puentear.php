<?php
$contenidoPrevio=file_get_contents("./datos/mensajes.txt");
echo $contenidoPrevio;
?>